import React from 'react';
import logo from './logo.svg';
import './App.css';
import Student from './student'
import Login from './login'

function App() {
  return (
    <div className="App">
     
      <Student/>
      <Login/>
    </div>
  );
}

export default App;
