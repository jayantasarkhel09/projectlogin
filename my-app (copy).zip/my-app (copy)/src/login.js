import React from 'react';
import { connect } from 'react-redux'
import { getStudents, getStudentsSuccess, getStudentsFailure, fetchStudents } from './slice/students'

 class Login extends React.Component {
    handleSubmit = () =>
    {

        this.props.students.map((student,index)=>
        {
           if(student.email===this.state.email)
           {
               if(student.password==this.state.password)
               {
                   alert("logged in");
               }
               else
               {
                alert("not logged in");

               }
           }
           else{
            alert("not logged in");
           }
        })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        
    
        
        
        this.setState({ [name]: value });
    
      }
    render()
    {
        console.log("props",this.props.students)
        return(
        
            <div>
               <h5> if you all ready regsiterd</h5>
                   <form onSubmit={this.handleSubmit} >
                 email <input type='email' name='email'   onChange={this.handleChange} /><br/>
                Password <input type='password' name='password'  onChange={this.handleChange}/>
                <div className='submit'>
              <button>Create</button>
            </div>

                </form>
                </div>
        )
        
    }


}

const mapStateToProps = (state /*, ownProps*/) => ({
    students: state.students.students
  })
  
  const mapDispatchToProps = { fetchStudents }
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(Login)