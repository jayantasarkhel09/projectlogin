import React from 'react';
import DatePicker from "react-datepicker";
import { connect } from 'react-redux'
import { getStudents, getStudentsSuccess, getStudentsFailure, fetchStudents } from './slice/students'
const validEmailRegex = RegExp(
  /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
);
const validateForm = errors => {
  let valid = true;
  Object.values(errors).forEach(val => val.length > 0 && (valid = false));
  return valid;
};

class Student extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fullName: null,
      email: null,
      password: null,
      dob: null,
      errors: {
        fullName: '',
        email: '',
        password: '',
      }
    };
  }
  handleDateChange = (date) => {

    //this.setState({ dob: date });
  }

  // componentWillReceiveProps(newProps, nextProps) {
  //   if (newProps != nextProps) {
  //     console.log("new props", newProps)
  //     this.setState({
  //       studentinfo: nextProps
  //     })
  //   }
  // }

  handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;

    
    
    this.setState({ errors, [name]: value });

  }

  handleSubmit = (event) => {
    let errors = this.state.errors;
    event.preventDefault();
    if (validateForm(this.state.errors)) {
      if (this.state.password == this.state.cnfpassword) {
        console.info('Valid Form')
        alert("valid");
        
        this.props.fetchStudents(this.state)
      }
      else {
        errors.passmatch = "password mismatch"
      }
    } else {
      alert("invalid");
      console.error('Invalid Form')
    }
  }

  render() {
    const { errors } = this.state;
    console.log(this.state.studentinfo)
    return (

      <div className='wrapper'>
        {this.state.password}
        <div className='form-wrapper'>
          <h2>Create Account</h2>
          <form onSubmit={this.handleSubmit} noValidate>
            <div className='fullName'>
              <label htmlFor="fullName">Full Name</label>
              <input type='text' name='fullName' onChange={this.handleChange} noValidate />
              {errors.fullName.length > 0 &&
                <span className='error'>{errors.fullName}</span>}
            </div>
            <div className='email'>
              <label htmlFor="email">Email</label>
              <input type='email' name='email' onChange={this.handleChange} noValidate />
              {errors.email.length > 0 &&
                <span className='error'>{errors.email}</span>}
            </div>
            <div className='password'>
              <label htmlFor="password">Password</label>
              <input type='password' name='password' onChange={this.handleChange} noValidate />
              {errors.password.length > 0 &&
                <span className='error'>{errors.password}</span>}
            </div>
            <div className='confirmpassword'>
              <label htmlFor="password">Confirm Password</label>
              <input type='password' name='cnfpassword' onChange={this.handleChange} noValidate />
              {errors.password.length > 0 &&
                <span className='error'>{errors.cnfpassword}</span>}
            </div>
            <div>
              <div>
                <label htmlFor="dob">dob</label>
                <input type="date" name="dob" onChange={this.handleDateChange} />
              </div>
            </div>

            <div className='submit'>
              <button>Create</button>
            </div>
          </form>
        </div>

        <div>
          {(this.props.students || []).map((student, index) => (
            <div key={index}>
              <h5>student-</h5>, {student.fullName} <h5>email </h5> {student.email}

            </div>
          ))}
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state /*, ownProps*/) => ({
  students: state.students.students
})

const mapDispatchToProps = { fetchStudents }
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Student)