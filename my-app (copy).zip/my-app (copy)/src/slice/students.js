import { createSlice } from '@reduxjs/toolkit'

export const initialState = {
  loading: false,
  hasErrors: false,
  students: [],
}

const studentSlice = createSlice({
  name: 'students',
  initialState,
  reducers: {
    getStudents: state => {
      state.loading = true
    },
    getStudentsSuccess: (state, { payload }) => {
      console.log("pay", payload)
      state.students.push(payload)
      state.loading = false
      state.hasErrors = false

    },
    getStudentsFailure: state => {
      state.loading = false
      state.hasErrors = true
    },
  },
})

export const { getStudents, getStudentsSuccess, getStudentsFailure } = studentSlice.actions
export const postSelector = state => state.post
export default studentSlice.reducer

export function fetchStudents(data) {
  return async dispatch => {
    dispatch(getStudentsSuccess(data))

  }
}